import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:oye/DataHandler/appData.dart';
import 'package:oye/scr/ui/login/loginScreen.dart';
import 'package:oye/scr/ui/main/homePage.dart';
import 'package:oye/scr/ui/register/register.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:provider/provider.dart';


Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}
DatabaseReference userRef = FirebaseDatabase.instance.reference().child("users");
class MyApp extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => AppData(),
      child: MaterialApp(
        title: 'Oyes',
        theme: ThemeData(
          fontFamily: "Raleway",
          primarySwatch: Colors.green,
          visualDensity: VisualDensity.adaptivePlatformDensity,
        ),
        // home: Registor(),
        initialRoute: FirebaseAuth.instance.currentUser == null ?  '/login' : '/home',
        routes: {
         
          '/login': (BuildContext context) => LoginScreen(),
          '/register': (BuildContext context) => Registor(),
          '/home': (BuildContext context) => HomePage(),
        },
        debugShowCheckedModeBanner: false,
      ),
    );
  }
}
