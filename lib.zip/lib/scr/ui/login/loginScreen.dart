import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:oye/main.dart';
import 'package:oye/scr/ui/register/register.dart';
import 'package:oye/scr/widgets/iinputField2.dart';
import 'package:oye/scr/widgets/iinputField2Password.dart';
import 'package:oye/scr/widgets/progressDailogo.dart';


class LoginScreen extends StatefulWidget {
  const LoginScreen({key}) : super(key: key);
  // static const String idScreen = "LoginScreen";


  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {

  TextEditingController emailTextEditingController = TextEditingController();
  TextEditingController passwordTextEditingController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black12,
      body: SingleChildScrollView(
       child: Padding(
         padding: EdgeInsets.all(8.0),
         child: Column(
           children: [
             SizedBox(height: 35.0,),
             Image(image: AssetImage("assets/images/logo.png"),
               width: 390.0,
               height: 250.0,
               alignment: Alignment.center,
             ),

             SizedBox(height: 1.0,),
             Padding(padding: EdgeInsets.all(20.0),
                 child: Column(
                   children: <Widget>[
                     SizedBox(height: 15,),
                     Container(
                         margin: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                         child: IInputField2(
                             controller: emailTextEditingController,

                             hint: "Login",            // "Login"
                             icon: Icons.alternate_email,
                             colorDefaultText: Colors.white,
                             colorBackground: Colors.black54,
                             // controller: editControllerName,
                             type: TextInputType.emailAddress
                         )
                     ),
                     SizedBox(height: 10,),
                     Container(
                         margin: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                         child: IInputField2Password(
                           controller: passwordTextEditingController,

                           hint: "Password",            // "Password"
                           icon: Icons.vpn_key,
                           colorDefaultText: Colors.white,
                           colorBackground: Colors.black54,
                           // controller: editControllerPassword,
                         )),
                     SizedBox(height: 10,),
                     Container(
                       margin: EdgeInsets.only(left: 20, right: 20),

                     ),
                     SizedBox(height: 10.0,),
                     RaisedButton(
                       color: Colors.yellow,
                       textColor: Colors.black,
                       child: Container(
                         height: 50.0,
                         child: Center(
                           child: Text(
                             "Login",
                             style: TextStyle(
                               fontSize: 18.0,
                               fontFamily: "Raleway",
                               fontWeight: FontWeight.w800
                             ),
                           ),
                         ),
                       ),
                       shape: new RoundedRectangleBorder(
                         borderRadius: new BorderRadius.circular(24.0),
                       ), onPressed: () {
                         loginUser(context);

                         },
                     ),
                     SizedBox(height: 15,),

                     Align(
                       alignment: Alignment.bottomCenter,
                       child: Column(
                         mainAxisSize: MainAxisSize.min,
                         children: <Widget>[
                           InkWell(
                               onTap: () {
                                 Navigator.pushNamedAndRemoveUntil(context, '/register', (route) => false)  ;
                               }, // needed
                               child:Container(
                                 padding: EdgeInsets.only(left: 20, right: 20, bottom: 10, top: 20),
                                 child: Text("Don't have an account? Create",                    // ""Don't have an account? Create",",
                                     overflow: TextOverflow.clip,
                                     textAlign: TextAlign.center,
                                     style: TextStyle(
                                       color: Colors.white,
                                       fontWeight: FontWeight.w800,
                                       fontSize: 16,
                                     )
                                 ),
                               )),
                           InkWell(
                               onTap: () {
                                 // _pressForgotPasswordButton();
                               }, // needed
                               child:Container(
                                 padding: EdgeInsets.all(20),
                                 child: Text("Forgot password",                    // "Forgot password",
                                     overflow: TextOverflow.clip,
                                     textAlign: TextAlign.center,
                                     style: TextStyle(
                                       color: Colors.white,
                                       fontWeight: FontWeight.w800,
                                       fontSize: 16,
                                     )
                                 ),
                               ))
                         ],
                       ),
                     ),
                   ],
                 )

             )
           ],
         ),
       ),
      ),

    );
  }

  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;
  void loginUser(BuildContext context)async {
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context){
          return ProgressDialog(
            message: "Login, Please wait...",
          );
        });
    var sign;
    final User firebaseUser = (await _firebaseAuth.signInWithEmailAndPassword(email:
    emailTextEditingController.text,
        password: passwordTextEditingController.text)).user;

    if(firebaseUser != null){
      userRef.child(firebaseUser.uid).once().then((DataSnapshot snap){
        if(snap.value != null)
        {
          Navigator.pushNamedAndRemoveUntil(context, '/home', (route) => false);
        }
        else
          {
            Navigator.pop(context);
            _firebaseAuth.signOut();}
      });
    }
  }
}

