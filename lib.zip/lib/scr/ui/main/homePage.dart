import 'dart:async';
import 'dart:math';
import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_geofire/flutter_geofire.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:oye/Assistants/AssistantMethods.dart';
import 'package:oye/Assistants/geofileAssistant.dart';
import 'package:oye/DataHandler/appData.dart';
import 'package:oye/scr/config/config.dart';
import 'package:oye/scr/models/directionDetails.dart';
import 'package:oye/scr/models/nearByAvailableDrivers.dart';
import 'package:oye/scr/ui/main/searchScreen.dart';
import 'package:oye/scr/widgets/divider.dart';
import 'package:oye/scr/widgets/progressDailogo.dart';
import 'package:provider/provider.dart';
// import 'package:google_maps_flutter/google_maps_flutter.dart';

class HomePage extends StatefulWidget {
  const HomePage({key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin
{
  Completer<GoogleMapController> _controllerGoogleMap = Completer();
  GoogleMapController newGoogleMapControllor;

  static final CameraPosition _kGooglePlex = CameraPosition(
    target: LatLng(37.42796133580664, -122.085749655962),
    zoom: 14.4746,
  );

  List<LatLng> pLineCordinates = [];
  Set<Polyline> polylineSet = {};

  Position currentPosition;
  var geolocator = Geolocator();
  double bottomPaddingOfMap = 0;

  bool drowerOpen = true;
  bool nearbyAvailableDriverKeysLoaded = false;

  double requestRidingContainer = 0;
  double searchContainerHeight = 300.0;
  double riderDetailsContainer = 0;

  restApp(){
    setState(() {
      drowerOpen = true;
      searchContainerHeight = 300;
      riderDetailsContainer = 0;
      requestRidingContainer = 0;
      bottomPaddingOfMap = 300.0;

      polylineSet.clear();
      markerSet.clear();
      circlesSet.clear();
      pLineCordinates.clear();

    });

    locatePosition();
  }

  Set<Marker> markerSet = {};
  Set<Circle> circlesSet = {};


  static const colorizeColors = [
    Colors.black,
    Colors.green,
    Colors.red,
    Colors.lightGreen,
  ];

  static const colorizeTextStyle = TextStyle(
    fontSize: 25.0,
    fontFamily: 'Raleway',
    fontWeight: FontWeight.bold,

  );

  void displayRiderDetailsContainer() async {
    await getPlaceDirection();

    setState(
        (){

          searchContainerHeight = 0;
          riderDetailsContainer = 250;
          bottomPaddingOfMap = 300.0;
          drowerOpen = false;
        });
  }

  // display requesting container
  void displayRequestingContainer() async
  {
    setState(() {
      // searchContainerHeight = 0;
      riderDetailsContainer = 0;
      requestRidingContainer = 250;
      bottomPaddingOfMap = 300.0;
      drowerOpen = false;
    });
    saveRideRequest();
  }

  void locatePosition() async {
    Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
    currentPosition = position;

    LatLng latLngPosition = LatLng((position.latitude), position.longitude);
    CameraPosition cameraPosition =
        new CameraPosition(target: latLngPosition, zoom: 14);
    newGoogleMapControllor
        .animateCamera(CameraUpdate.newCameraPosition(cameraPosition));

    String address =
        await AssistantMethods.searchCoordinateAddress(position, context);
    print("this is your address" + address);
    // print (placeAddress2);

    initGeoFireListener();
  }

  Completer<GoogleMapController> _controller = Completer();

  GlobalKey<ScaffoldState> scaffoldKey = new GlobalKey<ScaffoldState>();

  DirectionDetails tripDirectionDetails;

  static final CameraPosition _kLake = CameraPosition(
      bearing: 192.8334901395799,
      target: LatLng(37.43296265331129, -122.08832357078792),
      tilt: 59.440717697143555,
      zoom: 19.151926040649414);

  DatabaseReference rideRequestRef;

  @override
  void initState() {
    // TODO: implement initState
    AssistantMethods.getCurrentOnlineUserInfo();
  }

  void saveRideRequest()
  {
    rideRequestRef = FirebaseDatabase.instance.reference().child("Ride Request").push();

    var pickUp = Provider.of<AppData>(context, listen: false).pickUpLocation;
    var dropOff = Provider.of<AppData>(context, listen: false ).dropOffLocation;

    Map pickUpLocMap =
        {
          "latitude": pickUp.latitude.toString(),
          "longitude": pickUp.longitude.toString(),
        };

    Map dropOffLocMap =
    {
      "latitude": dropOff.latitude.toString(),
      "longitude": dropOff.longitude.toString(),
    };

    Map rideInfoMap =
        {
          "driver_id": "waiting",
          "payment_method": "cash",
          "pickup": pickUpLocMap,
          "dropoff" : dropOffLocMap,
          "created_at": DateTime.now().toString(),
          "rider_name": usersCurrentInfo.name,
          "pickup_address": pickUp.placeName,
          "dropoff_address": dropOff.placeName,
        };

    // to push this info to the database, we call
    rideRequestRef.set(rideInfoMap);

  }

  void cancelRideRequest()
  {
    rideRequestRef.remove();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      appBar: AppBar(
        title: Text('Oyes'),
      ),
      // backgroundColor: Colors.white,
      drawer: Container(
        color: Colors.white,
        width: 255.0,
        child: Drawer(
          child: ListView(
            children: [
              Container(
                height: 165.0,
                child: DrawerHeader(
                  decoration: BoxDecoration(color: Colors.white),
                  child: Row(
                    children: [
                      Image.asset(
                        "assets/images/usa.png",
                        height: 65.0,
                        width: 65.0,
                      ),
                      SizedBox(
                        width: 16.0,
                      ),


                      Column(
                        // mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            "Profile Name",
                            style: TextStyle(
                                fontSize: 16.0, fontFamily: "Raleway"),
                          ),

                          SizedBox(
                            height: 6.0,
                          ),

                          Text("Visit Profile"),
                        ],
                      )
                    ],
                  ),
                ),
              ),
              DividerWidget(),
              SizedBox(
                height: 12.0,
              ),
              // Drawer body/
              ListTile(
                leading: Icon(Icons.history),
                title: Text(
                  "History",
                  style: TextStyle(fontSize: 15),
                ),
              ),

              ListTile(
                leading: Icon(Icons.person),
                title: Text(
                  "Visit Profile",
                  style: TextStyle(fontSize: 15),
                ),
              ),

              ListTile(
                leading: Icon(Icons.info),
                title: Text(
                  "About",
                  style: TextStyle(fontSize: 15),
                ),
              ),

              // signout
              GestureDetector(
                onTap: (){
                  FirebaseAuth.instance.signOut();
                  Navigator.pushNamedAndRemoveUntil(context, '/login', (route) => false);
                },
                child: ListTile(
                  leading: Icon(Icons.info),
                  title: Text(
                    "Sign Out",
                    style: TextStyle(fontSize: 15),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),



      body: Stack(
        children: [
          // google Maps
          GoogleMap(
            padding: EdgeInsets.only(bottom: bottomPaddingOfMap),
            mapType: MapType.normal,
            myLocationButtonEnabled: true,
            initialCameraPosition: _kGooglePlex,

            markers: markerSet,
            circles: circlesSet,
            myLocationEnabled: true,
            zoomGesturesEnabled: true,
            zoomControlsEnabled: true,
            polylines: polylineSet,
            onMapCreated: (GoogleMapController controller) {
              _controllerGoogleMap.complete(controller);
              newGoogleMapControllor = controller;

              setState(() {
                bottomPaddingOfMap = 300.0;
              });
              locatePosition();
            },
          ),

          // HamburgerButton for the drawer
          Positioned(
            top: 35.0,
            left: 22.0,
            child: GestureDetector(
              onTap: () {
                if(drowerOpen){
                  scaffoldKey.currentState.openDrawer();
                }
                else
                  {
                    restApp();
                  }

              },
              child: Container(
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(32.0),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black,
                        blurRadius: 6.0,
                        spreadRadius: 0.5,
                        offset: Offset(
                          0.7,
                          0.7,
                        ),
                      )
                    ]),
                child: CircleAvatar(
                    backgroundColor: Colors.white,
                    child: Icon((drowerOpen)?Icons.menu : Icons.close, color: Colors.black)),
              ),
            ),
          ),

          //location picker
          Positioned(
              left: 0.0,
              right: 0.0,
              bottom: 0.0,
              child: AnimatedSize(
                vsync: this,
                curve: Curves.bounceIn,
                duration: new Duration(milliseconds: 160),
                child: Container(
                  height: searchContainerHeight,
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(18.0),
                        topRight: Radius.circular(18.0),
                      ),
                      boxShadow: [
                        BoxShadow(
                            color: Colors.black,
                            blurRadius: 16.0,
                            spreadRadius: 0.5,
                            offset: Offset(0.7, 0.7)),
                      ]),


                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 24.0, vertical: 18.0),
                    child: Column(
                      // mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          height: 6.0,
                        ),
                        Text(
                          "Hi there",
                          style: TextStyle(
                              fontWeight: FontWeight.w600, fontSize: 12.0),
                        ),
                        Text(
                          "Where do want to Drop Off",
                          style: TextStyle(
                            fontSize: 18.0,
                            fontFamily: "Raleway-Bold",
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        SizedBox(
                          height: 20,
                        ),


                        GestureDetector(
                          onTap: () async {
                            var res = await Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => SearchScreen()));

                            if (res == "obtainDirection") {
                              // await getPlaceDirection();
                              await displayRiderDetailsContainer();
                            }
                          },
                          child: Container(
                            decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(5.0),
                                boxShadow: [
                                  BoxShadow(
                                      color: Colors.black54,
                                      blurRadius: 6.0,
                                      spreadRadius: 0.5,
                                      offset: Offset(0.7, 0.7)),
                                ]),
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Row(
                                children: [
                                  Icon(Icons.search, color: Colors.blueAccent),
                                  SizedBox(
                                    width: 10.0,
                                  ),
                                  Text("Search Drop off")
                                ],
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: 24.0),
                        Row(
                          children: [
                            Icon(
                              Icons.home,
                              color: Colors.grey,
                            ),
                            SizedBox(
                              width: 12.0,
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  Provider.of<AppData>(context).pickUpLocation !=
                                          null
                                      ? Provider.of<AppData>(context)
                                          .pickUpLocation
                                          .placeName
                                      : "Add PickUp Location",
                                  style: TextStyle(
                                    fontSize: 12.0,
                                    fontFamily: "Raleway-Bold",
                                  ),
                                ),
                                SizedBox(
                                  height: 4.0,
                                ),
                                Text(
                                  "Enter New Pickup or home Location",
                                  style: TextStyle(
                                      color: Colors.black54, fontSize: 12.0),
                                )
                              ],
                            )
                          ],
                        ),
                        SizedBox(height: 10.0),
                        DividerWidget(),
                        SizedBox(height: 16.0),
                        Row(
                          children: [
                            Icon(
                              Icons.work,
                              color: Colors.grey,
                            ),
                            SizedBox(
                              width: 12.0,
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Add Work",
                                  style: TextStyle(
                                      fontSize: 12.0, fontFamily: "Raleway-Bold"),
                                ),
                                SizedBox(
                                  height: 4.0,
                                ),
                                Text(
                                  "Your office Address",
                                  style: TextStyle(
                                      color: Colors.black54, fontSize: 12.0),
                                )
                              ],
                            )
                          ],
                        )
                      ],
                    ),
                  ),
                ),
              )),

        //  vehicles
          Positioned(
            bottom: 0.0,
            left: 0.0,
            right: 0.0,

            child: AnimatedSize(
              vsync: this,
              curve: Curves.bounceIn,
              duration: new Duration(milliseconds: 160),
              child: Container(
                height: riderDetailsContainer,
                decoration: BoxDecoration(
                    color: Colors.tealAccent,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(18.0),
                      topRight: Radius.circular(18.0),
                    ),
                    boxShadow: [
                      BoxShadow(
                          color: Colors.black,
                          blurRadius: 16.0,
                          spreadRadius: 0.5,
                          offset: Offset(0.7, 0.7)),
                    ]
                ),
                child: Padding(
                  padding: EdgeInsets.symmetric(vertical: 17.0,),
                  child: Column(

                    children: [
                      Container(
                        width: double.infinity,
                        color: Colors.tealAccent,
                        child: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 16.0,),
                          child: Row(
                            children: [
                              Image.asset("assets/images/taxi.png",height: 70.0, width: 80.0,),
                              SizedBox(width: 16.0,),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [

                                  Text("Car", style: TextStyle(fontSize: 18.0, fontWeight: FontWeight.w600, fontFamily: "Raleway")),

                                  Text(
                                      ((tripDirectionDetails != null)? tripDirectionDetails.distanceText : " " ),
                                      style: TextStyle(fontSize: 12.0, fontWeight: FontWeight.w600, fontFamily: "Raleway")),

                                ],
                              ),
                              Expanded(child: Container()),
                              Text(
                                  ((tripDirectionDetails != null) ?  '\$${AssistantMethods.calculateFares(tripDirectionDetails)}' : " "),
                                  style: TextStyle(fontSize: 18.0, fontWeight: FontWeight.w600, fontFamily: "Raleway")),
                            ],
                          ),
                        )

                      ),

                      SizedBox(height: 20.0,),
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 16.0),
                        child: Row(
                          children: [
                            Icon(FontAwesomeIcons.moneyCheckAlt, size: 18.0, color: Colors.black,),
                            SizedBox(width: 16.0,),
                            Text("Cash"),
                            SizedBox(width: 6.0,),
                            Icon(Icons.keyboard_arrow_down, color: Colors.black54, size: 16,),// font_awesome_flutter
                          ],
                        ) ,
                      ),
                      // width: double.infinity,
                      // wid
                      SizedBox(height: 0.0,),

                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 16.0),
                        child: RaisedButton(
                          onPressed: (){
                            print("request container called");
                            displayRequestingContainer();
                            },


                          color: Colors.black87,
                          child: Padding(
                            padding: EdgeInsets.fromLTRB(5.0, 0.0,5.0,0.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                 Text(
                                   "Request", style: TextStyle( fontSize: 20.0, fontWeight: FontWeight.bold, color: Colors.white),
                                 ),
                                Icon(FontAwesomeIcons.taxi, color: Colors.white, size: 18.0)
                              ]
                            ),
                          ),

                           ),

                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),

          Positioned(
            bottom: 0.0,
            left: 0.0,
            right: 0.0,
            child: SingleChildScrollView(
              child: Container(
                height: requestRidingContainer ,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only( topLeft: Radius.circular(16.0) , topRight:  Radius.circular(16.0),
                  ),
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                      spreadRadius: 0.5,
                      blurRadius: 16.0,
                      color: Colors.black,
                      offset: Offset(0.7,0.7),
                    )
                  ],
                ),
                child: Padding(
                  padding: EdgeInsets.all(30.0),
                  child: Column(
                    children: [

                      SizedBox(height: 12.0,),

                      SizedBox(
                        width: double.infinity,
                        child: AnimatedTextKit(
                            animatedTexts: [
                                ColorizeAnimatedText(
                                'Requesting for a ride ...',
                                textStyle: colorizeTextStyle,
                                textAlign: TextAlign.center,
                                colors: colorizeColors,
                                ),
                                ColorizeAnimatedText(
                                'Please wait ..........',
                                textStyle: colorizeTextStyle,
                                  textAlign: TextAlign.center,

                                  colors: colorizeColors,
                                ),
                                ColorizeAnimatedText(
                                'Finding a Driver....',
                                textStyle: colorizeTextStyle,
                                  textAlign: TextAlign.center,

                                  colors: colorizeColors,
                                ),
                            ],
                        isRepeatingAnimation: true,
                        onTap: () {
                        print("Tap Event");
                        },
                        ),
                      ),
                      SizedBox(height: 22.0,),
                      GestureDetector(
                        onTap: (){
                          cancelRideRequest();
                          restApp();
                        },
                        child: Container(
                          height: 60.0,
                          width: 60.0,

                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(26.0),
                            border: Border.all(width: 2.0, color: Colors.grey[300]),
                          ),
                          child: Icon(Icons.close, size: 26.0),


                        ),
                      ),
                      
                      SizedBox(height: 10.0),
                      Container(
                        width: double.infinity,
                        child: Text(
                          "Cancel Ride",
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 10.0,fontWeight: FontWeight.bold, fontFamily: 'Raleway'),),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> getPlaceDirection() async
  {
    var initialPos = Provider.of<AppData>(context, listen: false).pickUpLocation;
    var finalPos =   Provider.of<AppData>(context, listen: false).dropOffLocation;

    var pickUpLatLng  = LatLng(initialPos.latitude, initialPos.longitude);
    var dropOffLapLng = LatLng(finalPos.latitude, finalPos.longitude);

    showDialog(
        context: context,
        builder: (BuildContext context) => ProgressDialog(
              message: "Please Wait...",
            ));

    var details = await AssistantMethods.obtainDirectionsDetails(pickUpLatLng, dropOffLapLng);
    setState(() {
      tripDirectionDetails = details;
    });



    Navigator.pop(context);

    print("This is encoded points:::::::::");
    print("_______:-");
    print("___________:-");
    print("_______________:-");
    print("___________________:-");
    print("_______________________:-");
    print("_______sds____________________:-");
    print(details.encodedPoints);

    print("_______________:-");
    print("___________________:-");
    print("____________above___________:-");
    print("___________________________:-");

    PolylinePoints polylinePoints = PolylinePoints();
    List<PointLatLng> decodedPolylinePointsResult = polylinePoints.decodePolyline(details.encodedPoints);

    pLineCordinates.clear();

    if (decodedPolylinePointsResult.isNotEmpty) {
      decodedPolylinePointsResult.forEach((PointLatLng pointLatLng) {
        pLineCordinates.add(LatLng(pointLatLng.latitude, pointLatLng.longitude));
      });
    }

    polylineSet.clear();

    setState(() {
      Polyline polyline = Polyline(
        color: Colors.pink,
        polylineId: PolylineId("PolylineID"),
        jointType: JointType.round,
        points: pLineCordinates,
        width: 5,
        startCap: Cap.roundCap,
        endCap: Cap.roundCap,
        geodesic: true,
      );

      polylineSet.add(polyline);
    });

    LatLngBounds latLngBounds;
    if (pickUpLatLng.latitude > dropOffLapLng.latitude &&
        pickUpLatLng.longitude > dropOffLapLng.longitude) {
      latLngBounds =
          LatLngBounds(southwest: dropOffLapLng, northeast: pickUpLatLng);
    } else if (pickUpLatLng.longitude > dropOffLapLng.longitude) {
      latLngBounds = LatLngBounds(
          southwest: LatLng(pickUpLatLng.latitude, dropOffLapLng.longitude),
          northeast: LatLng(dropOffLapLng.latitude, pickUpLatLng.longitude));
    } else if (pickUpLatLng.latitude > dropOffLapLng.latitude) {
      latLngBounds = LatLngBounds(
          southwest: LatLng(dropOffLapLng.latitude, pickUpLatLng.longitude),
          northeast: LatLng(pickUpLatLng.latitude, pickUpLatLng.longitude));
    } else {
      latLngBounds =
          LatLngBounds(southwest: pickUpLatLng, northeast: dropOffLapLng);
    }

    newGoogleMapControllor
        .animateCamera(CameraUpdate.newLatLngBounds(latLngBounds, 70));

    //pickUp Marker
    Marker pickUpLocationMarker = Marker(
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueYellow),
        infoWindow:
            InfoWindow(title: initialPos.placeName, snippet: "Pickup Location"),
        markerId: MarkerId("pickUpId")
    );

    //  drop off marker
    Marker dropOffLocationMarker = Marker(
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
        infoWindow:
            InfoWindow(title: finalPos.placeName, snippet: "Dropoff Location"),
        markerId: MarkerId("dropOffId")
    );

    setState(()
      {
        markerSet.add(pickUpLocationMarker);
        markerSet.add(dropOffLocationMarker);
      }
    );

    // Circle
    Circle pickUpLocCircle = Circle(
        fillColor: Colors.blue,
        center: pickUpLatLng,
        radius: 12,
        strokeWidth: 4,
        strokeColor: Colors.blueAccent,
        circleId: CircleId("pickUpId")
    );

    Circle dropOffLocCircle = Circle(
        fillColor: Colors.pink,
        center: dropOffLapLng,
        radius: 12,
        strokeWidth: 4,
        strokeColor: Colors.pinkAccent,
        circleId: CircleId("dropOffId")
    );


    setState(() {
      circlesSet.add(pickUpLocCircle);
      circlesSet.add(dropOffLocCircle);
    });
  }

  void initGeoFireListener()
  {
    Geofire.initialize("Available_drivers");
    //connect
    Geofire.queryAtLocation(30.730743, 76.774948, 10).listen((map) {
      print(map);
      if (map != null) {
        var callBack = map['callBack'];


        switch (callBack) {
          case Geofire.onKeyEntered:

          NearByAvailableDrivers nearByAvailableDrivers = NearByAvailableDrivers();

          nearByAvailableDrivers.key = map['key'];
          nearByAvailableDrivers.latitude = map['latitude'];
          nearByAvailableDrivers.longitude = map['longitude'];

          GeoFireAssistant.nearByAvailableDriversList.add(nearByAvailableDrivers);

          if( nearbyAvailableDriverKeysLoaded == true)
            {
              updatedAvailableDriversOnMap();
            }

          break;

          case Geofire.onKeyExited:

            GeoFireAssistant.removeDriverFromList(map['key']);
            updatedAvailableDriversOnMap();
            break;

          case Geofire.onKeyMoved:

            NearByAvailableDrivers nearByAvailableDrivers = NearByAvailableDrivers();

            nearByAvailableDrivers.key = map['key'];
            nearByAvailableDrivers.latitude = map['latitude'];
            nearByAvailableDrivers.longitude = map['longitude'];

            GeoFireAssistant.updatedDriverNearByLocation(nearByAvailableDrivers);
            updatedAvailableDriversOnMap();
            break;

          case Geofire.onGeoQueryReady:
            updatedAvailableDriversOnMap();

            break;
        }
      }

      setState(() {});
    });

    // connect
  }

  void updatedAvailableDriversOnMap()
  {
    setState(() {
      markerSet.clear();
    });

    Set<Marker> tMarkers = Set<Marker>();
    for(NearByAvailableDrivers driver in GeoFireAssistant.nearByAvailableDriversList )
      {
        LatLng driverAvailablePosition = LatLng(driver.latitude, driver.longitude);


        Marker marker = Marker(
          markerId: MarkerId('driver${driver.key}'),
          position: driverAvailablePosition,
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueYellow),
          rotation: AssistantMethods.createRandomNumber(360),
        );

        tMarkers.add(marker);
      }
    setState(() {
      markerSet = tMarkers;
    });
  }
}
