import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:oye/main.dart';
import 'package:oye/scr/ui/login/loginScreen.dart';
import 'package:oye/scr/widgets/progressDailogo.dart';

class Registor extends StatefulWidget {
  const Registor({key}) : super(key: key);
  // static const String idScreen = "register";


  @override
  _RegistorState createState() => _RegistorState();
}

class _RegistorState extends State<Registor> {
  TextEditingController nameTextEditingController = TextEditingController();
  TextEditingController emailTextEditingController = TextEditingController();
  TextEditingController phoneTextEditingController = TextEditingController();
  TextEditingController passwordTextEditingController = TextEditingController();


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black12,
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(8.0),
          child: Column(
            children: [
              SizedBox(height: 25.0,),
              Image(image: AssetImage("assets/images/logo.png"),
                width: 390.0,
                height: 250.0,
                alignment: Alignment.center,
              ),

              SizedBox(height: 1.0,),



              Padding(padding: EdgeInsets.all(20.0),
                  child: Column(
                    children: <Widget>[

                      SizedBox(height: 1.0,),
                      TextField(
                        controller: nameTextEditingController,
                        keyboardType: TextInputType.emailAddress,
                        decoration: InputDecoration(
                          labelText: "Name",
                          labelStyle: TextStyle(
                            color: Colors.white,
                            fontSize: 14.0,
                          ),
                          hintStyle: TextStyle(
                            color: Colors.white,
                            fontSize: 10.0,
                          )
                        ),
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 14.0),
                      ),

                      SizedBox(height: 1.0,),
                      TextField(
                        controller: emailTextEditingController,
                        keyboardType: TextInputType.emailAddress,
                        decoration: InputDecoration(
                            labelText: "Email",
                            labelStyle: TextStyle(
                              color: Colors.white,
                              fontSize: 14.0,
                            ),
                            hintStyle: TextStyle(
                              color: Colors.white,
                              fontSize: 10.0,
                            )
                        ),
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 14.0),
                      ),

                      SizedBox(height: 1.0,),
                      TextField(
                        controller: phoneTextEditingController,

                        keyboardType: TextInputType.phone,
                        decoration: InputDecoration(
                            labelText: "Phone Number",
                            labelStyle: TextStyle(
                              color: Colors.white,
                              fontSize: 14.0,
                            ),
                            hintStyle: TextStyle(
                              color: Colors.white,
                              fontSize: 10.0,
                            )
                        ),
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 14.0),
                      ),

                      SizedBox(height: 1.0,),
                      TextField(
                        controller: passwordTextEditingController,
                        keyboardType: TextInputType.emailAddress,
                        decoration: InputDecoration(
                            labelText: "Password",
                            labelStyle: TextStyle(
                              color: Colors.white,
                              fontSize: 14.0,
                            ),
                            hintStyle: TextStyle(
                              color: Colors.white,
                              fontSize: 10.0,
                            )
                        ),
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 14.0),
                      ),
                      SizedBox(height: 1.0,),

                      SizedBox(height: 10,),
                      Container(
                        margin: EdgeInsets.only(left: 20, right: 20),

                      ),
                      SizedBox(height: 10.0,),
                      RaisedButton(
                        color: Colors.yellow,
                        textColor: Colors.black,
                        child: Container(
                          height: 50.0,
                          child: Center(
                            child: Text(
                              "Create an Account",
                              style: TextStyle(
                                  fontSize: 12.0,
                                  fontFamily: "Raleway",
                                  fontWeight: FontWeight.w800
                              ),
                            ),
                          ),
                        ),
                        shape: new RoundedRectangleBorder(
                          borderRadius: new BorderRadius.circular(24.0),
                        ), onPressed: () {
                          regesterNewUser(context);
                      },
                      ),
                      SizedBox(height: 15,),

                      Align(
                        alignment: Alignment.bottomCenter,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: <Widget>[
                            InkWell(
                                onTap: () {
                                  Navigator.pushNamedAndRemoveUntil(context, '/login', (route) => false);
                                }, // needed
                                child:Container(
                                  padding: EdgeInsets.only(left: 20, right: 20, bottom: 10, top: 20),
                                  child: Text("Already have an account? Login",                    // ""Don't have an account? Create",",
                                      overflow: TextOverflow.clip,
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.w800,
                                        fontSize: 16,
                                      )
                                  ),
                                )),
                            InkWell(
                                onTap: () {
                                  // _pressForgotPasswordButton();
                                }, // needed
                                child:Container(
                                  padding: EdgeInsets.all(20),
                                  child: Text("Forgot password",                    // "Forgot password",
                                      overflow: TextOverflow.clip,
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.w800,
                                        fontSize: 16,
                                      )
                                  ),
                                ))
                          ],
                        ),
                      ),


                    ],
                  )


              )
            ],
          ),
        ),
      ),


    );
  }

  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;

  void regesterNewUser(BuildContext context) async {
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context){
          return ProgressDialog(
            message: "Registoring, Please wait...",
          );
        });

    final  User firebaseUser = (await _firebaseAuth.createUserWithEmailAndPassword(
        email: emailTextEditingController.text,
        password: passwordTextEditingController.text)
    ).user;

    if(firebaseUser != null){
      // save the user info to the database
      userRef.child(firebaseUser.uid);

      Map userDataMap = {
        "name": nameTextEditingController.text.trim(),
        "email": emailTextEditingController.text.trim(),
        "phone": phoneTextEditingController.text.trim(),
        "password": passwordTextEditingController.text.trim()
      };
      // userRef

      userRef.child(firebaseUser.uid).set(userDataMap);

      Navigator.pushNamedAndRemoveUntil(context, '/home', (route) => false);
    }

    // try {
    //   UserCredential userCredential = await FirebaseAuth.instance.createUserWithEmailAndPassword(
    //
    //       email: emailTextEditingController.text.trim(),
    //       password: passwordTextEditingController.text.trim());
    //   // );
    // } on FirebaseAuthException catch (e) {
    //   if (e.code == 'weak-password') {
    //     print('The password provided is too weak.');
    //   } else if (e.code == 'email-already-in-use') {
    //     print('The account already exists for that email.');
    //   }
    // } catch (e) {
    //   print(e);
    // }
    // if the firebaseUser != null);
    // final FirebaseUser firebaseUser = (await _firebaseAuth.createUserWithEmailAndPassword(email: emailTextEditingController.text,
    // password: passwordTextEditingController.text)).user;

  }

}
