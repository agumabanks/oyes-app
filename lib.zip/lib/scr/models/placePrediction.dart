class PlacePrediction
{
  String place_id;
  String secondary_text;
  String main_text;
  PlacePrediction({this.main_text, this.place_id, this.secondary_text});

  PlacePrediction.fromJson(Map<String, dynamic>json){
    place_id = json["place_id"];
    secondary_text = json["structured_formatting" ]["secondary_text"];
    main_text = json["structured_formatting" ]["main_text"];


  }
}