class Address
    {
      String placeFormattedAddress;
      String placeName;
      String palceId;
      double latitude;
      double longitude;

      // Address({ this.longitude, this.latitude, this.palceId, this.placeFormattedAddress, this.placeName});
      Address({this.placeFormattedAddress, this.placeName, this.palceId, this.latitude, this.longitude});

    }