class NearByAvailableDrivers
{
  String key;
  double latitude;
  double longitude;

  NearByAvailableDrivers({this.key, this.latitude, this.longitude});

}