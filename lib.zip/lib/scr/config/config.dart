import 'package:firebase_auth/firebase_auth.dart';
import 'package:oye/scr/models/userModel.dart';

String mapKey = "AIzaSyBLV7mu49-p4Hgme7BLDBzvnPmIBIL2FQM";

User firebaseUser;

Users usersCurrentInfo;