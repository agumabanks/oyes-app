import 'package:oye/scr/models/nearByAvailableDrivers.dart';

class GeoFireAssistant
{
  static List<NearByAvailableDrivers> nearByAvailableDriversList = [];

  static void removeDriverFromList(String key)
  {
    int index = nearByAvailableDriversList.indexWhere((element) => element.key == key);
    nearByAvailableDriversList.removeAt(index);
  }

  static void updatedDriverNearByLocation (NearByAvailableDrivers drivers)
  {
    int index = nearByAvailableDriversList.indexWhere((element) => element.key == drivers.key);

    nearByAvailableDriversList[index].latitude = drivers.latitude;
    nearByAvailableDriversList[index].longitude = drivers.longitude;

  }
}