import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
class RequestAssistant
{
  // var url = Uri.parse('https://example.com/whatsit/create');

  static Future<dynamic> getRequest(String url) async
  {
    http.Response response = await http.get(Uri.parse(url));

    try
        {
          if( response.statusCode == 200){
            String jsonData = response.body;
            var decodeData = jsonDecode(jsonData);
            return decodeData;
          }
          else
            {
              return "failed";
            }

        }
        catch(exp){
          return "failed";
        }
  }
}